
var HDWalletProvider = require("truffle-hdwallet-provider");
const infuraKey = "7e6520f7db7f4e3aa371565a82010695";
//
// const fs = require('fs');
//const mnemonic = fs.readFileSync(".secret").toString().trim();
const mnemonic = "float unique february tragic giant cricket inmate option crush craft number pill";

module.exports = {


  networks: {
 
  
    development: {
      host: "127.0.0.1",
      port: 9545,
      network_id: "*"
     },
     
    rinkeby: {                                
      provider: function() { 
        return new HDWalletProvider(mnemonic, "https://rinkeby.infura.io/v3/7e6520f7db7f4e3aa371565a82010695");
       },
       network_id: 4,
       gas: 4500000,
       gasPrice: 10000000000,
    },


  },

  // Set default mocha options here, use special reporters etc.
  mocha: {
    // timeout: 100000
  },

  // Configure your compilers
  compilers: {
    solc: {
      // version: "0.5.1",    // Fetch exact version from solc-bin (default: truffle's version)
      version: "0.6.2",
      // docker: true,        // Use "0.5.1" you've installed locally with docker (default: false)
      // settings: {          // See the solidity docs for advice about optimization and evmVersion
      //  optimizer: {
      //    enabled: false,
      //    runs: 200
      //  },
      //  evmVersion: "byzantium"
      // }
    }
  }
}
